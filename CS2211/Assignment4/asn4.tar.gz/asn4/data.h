typedef struct {char *key; int data;} Node;
void print_node(Node node);
char *key_dup(char *key);
